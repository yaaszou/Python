for y in range(999999999999999999999999):
    if y % 2 == 0:
        print(y)