x = int(input('Insira um numero: '))
print(x*2)

