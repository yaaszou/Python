x = int(input('Fala um numerozinho por favor: '))
for y in range(1000):
    print(y)