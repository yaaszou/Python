x = int(input('Insira um numerozinho por gentileza: '))
y = int(input('Insira outro numerozinho por gentileza: '))
outravariavel = int(input('Insira a sua operaçao por obsequio, sendo 1 para soma, 2 para subtraçao, 3 para multiplicaçao e 4 para divisao: '))

if outravariavel == 1:
    resultado = x+y
    print('Resultado ',resultado)
elif outravariavel == 2:
    resultado = x-y
    print('Resultado ', resultado)
elif outravariavel == 3:
    resultado = x*y
    print('Resultado ', resultado)
else:
    resultado = x/y
    print('Resultado ', resultado)
